/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.Nicon.Personal.LibCore.Sbin;

import java.awt.Desktop;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.Nicon.Personal.LibCore.Obj.TwitterConfigAcount;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;
import twitter4j.conf.ConfigurationBuilder;



/**
 *
 * @author Frederick Adolfo Salazar Sanchez
 * 
 */
public class NiconTwitt {
    
   
    private RequestToken requestToken;
    private AccessToken accesToken;
    private NiconFileAdministrator NiconFileAdmin;
    private TwitterConfigAcount tca;
    
    private Twitter twitter;
    private ConfigurationBuilder cb;
    
    /**
     * 
     */
    public NiconTwitt(){
        
    }
    
    /**
     * Este es el metodo que permite el registro y Login de un usuario de NiconPersonal a la API
     * de twitter. hace uso de la libreria Twitter4J que a su vez implementa el protocolo de 
     * registro denominado OAuth. toma la configracion proveniente de Api.twiiter.com y la guarda
     * en el archivo de configuracion de cuentas en ./Config
     * 
     */
    public void loginTwitterCount(){
        NiconFileAdmin=new NiconFileAdministrator();
        try{
            if(!NiconFileAdmin.verifyFileExistSimple("TCA.npc", "./Config")){
                ConfigurationBuilder cb=new ConfigurationBuilder();
                cb.setDebugEnabled(true);
                cb.setOAuthConsumerKey(GlobalConfigSystem.getCONSUMER_KEY());
                cb.setOAuthConsumerSecret(GlobalConfigSystem.getCONSUMER_SECRET());
                Twitter twitterAcount=new TwitterFactory(cb.build()).getInstance();
                requestToken = twitterAcount.getOAuthRequestToken();
                System.out.println("Obtenido request token.");
                System.out.println("Request token: " + requestToken.getToken());
                System.out.println("Request token secret: " + requestToken.getTokenSecret());
                Desktop.getDesktop().browse(new URI (requestToken.getAuthorizationURL()));
                String Pin=JOptionPane.showInputDialog("Ingrese por favor el pin obtenido:");
                accesToken=twitterAcount.getOAuthAccessToken(requestToken, Pin);
                System.out.println("Obtenido el access token.");
                System.out.println("Access token: " + accesToken.getToken());
                System.out.println("Access token secret: " + accesToken.getTokenSecret());
                TwitterConfigAcount tca=new TwitterConfigAcount(accesToken);
                NiconFileAdmin=new NiconFileAdministrator(tca,"./Config","TCA.npc");
                NiconFileAdmin.writeFileObject();
            }else{
                tca=NiconFileAdmin.readFileObject("./Config/TCA.npc");
                System.out.println("El objecto de configuracion ya esta preparado");
                accesToken=tca.getDataAccessToken();
                System.out.println(accesToken);
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    /**
     * este metodo permite actualizar el estado en twitter de la cuenta del usuario propietario
     * hace uso de ConfigurationBuider para hacer la configuracion de login con el AccesToken
     * capturado desde el archivo de configruacion de cuentas en ./Config
     * @param String status
     * 
     */
    public void updateStatus(String status) {
        if(status!=null){
            try {
                cb=new ConfigurationBuilder();
                cb.setDebugEnabled(true);
                cb.setOAuthConsumerKey(GlobalConfigSystem.getCONSUMER_KEY());
                cb.setOAuthConsumerSecret(GlobalConfigSystem.getCONSUMER_SECRET());
                cb.setOAuthAccessToken(accesToken.getToken());
                cb.setOAuthAccessTokenSecret(accesToken.getTokenSecret());
                twitter=new TwitterFactory(cb.build()).getInstance();
                twitter.updateStatus(status);                
            } catch (TwitterException ex) {
               JOptionPane.showMessageDialog(null, "Ocurrió un error Grave y no se pudo enviar su Twett. verfique su conexión a internet\no comuniquese con NiconSystem y reporte su problema", GlobalConfigSystem.getTitleAplication(), JOptionPane.ERROR_MESSAGE);
               Logger.getLogger(NiconTwitt.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
}
